package com.lsq.lsqweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LsqWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(LsqWebApplication.class, args);
	}

}
